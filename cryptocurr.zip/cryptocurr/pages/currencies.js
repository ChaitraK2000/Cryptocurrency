import react from 'react';

const currencies = () => {
    return(
        <div>
            <h3 className="cur font">Top 100 Cryptocurrencies by Market Cap</h3>
        </div>
    )
}

export default currencies;