import react from 'react';
import Table from 'react-bootstrap/Table';
const details = () => {
    return(
        <div>
            <h2 class="e"><b>Bitcoin details</b></h2>
            <Table bordered striped hover className="details">
                <tr className="tr">
                <th className="th">Started</th>
                <td>30 July 2015<br/>over 5 years ago</td>
                </tr>
                <tr className="tr">
                <th className="th">White Paper</th>
                <td><img width="100px" src="https://encrypted-tbn0.gstatic.com/images?q=tbn%3AANd9GcQmvzEmHZ4qd1F-bRztPadzt6wH9fubS0f_aQ&usqp=CAU"/>
                <br/><a href="https://static.coinpaprika.com/storage/cdn/whitepapers/215.pdf">Open</a></td>
                </tr>
                <tr className="tr">
                <th className="th">Development status</th>
                <td>Working product</td>
                </tr>
                <tr className="tr">
                <th className="th">Org. Structure</th>
                <td>Semi-centralized</td>
                </tr>
                <tr className="tr">
                <th className="th">Open Source</th>
                <td>Yes</td>
                </tr>
                <tr className="tr">
                <th className="th">Consensus Mechanism</th>
                <td>Bitcoin consensus <br/>(currently proof of work, will be proof of<br/> stake later on)</td>
                </tr>
                <tr className="tr">
                <th className="th">Algorithm</th>
                <td>Ethash</td>
                </tr>
                <tr className="tr">
                <th className="th">Hardware wallet</th>
                <td>Yes</td>
                </tr>
            </Table>
        </div>
    )
}
export default details;