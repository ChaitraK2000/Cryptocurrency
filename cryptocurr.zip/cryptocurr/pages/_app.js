import React from 'react'
import 'react-bootstrap-table/dist/react-bootstrap-table.min.css';

import 'bootstrap/dist/css/bootstrap.min.css';
import '../components/Stylesheet.css';
import 'reactjs-popup/dist/index.css';
import 'react-circular-progressbar/dist/styles.css';
import "react-datepicker/dist/react-datepicker.css";
import 'react-datepicker/dist/react-datepicker-cssmodules.css';

export default function MyApp({ Component, pageProps }) {
  return <Component {...pageProps} />
}