import {react,useState} from 'react';
import Tabs from 'react-bootstrap/Tabs';
import Tab from 'react-bootstrap/Tab';
import Currencies from './currencies';
import DeFi from './defi';
import TokenizedAssets from './token';
import ICOs from './ico';

function nav() {
    const [key, setKey] = useState('Currencies');
  
    return (
      <Tabs className="tab1"
        transition={false}
        variant='pills'
        id="controlled-tab-example"
        activeKey={key}
        onSelect={(k) => setKey(k)}
      >
        <Tab eventKey="Currencies" title={<span className="title">Currencies</span>} className="tabs">
            <Currencies/>
        </Tab>
        <Tab eventKey="DeFi" title={<span className="title">DeFi</span>} className="tabs">
            <DeFi/>
        </Tab>
        <Tab eventKey="TokenizedAssets" title={<span className="title">Tokenized Assets</span>} className="tabs">
            <TokenizedAssets/>
        </Tab>
        <Tab eventKey="ICOs" title={<span className="title">ICOs</span>} className="tabs">
            <ICOs/>
        </Tab>
        
      </Tabs>
    );
  }

export default nav;