import react from 'react';

const defi = () => {
    return(
        <div className="defi">
            <h3 className="de font">Top DeFi based cryptocurrencies</h3>
            DeFi means 'decentralized finance' and is referred to as 'open finance'. It’s an ecosystem of financial apps that are developed on top of blockchain systems. It is permissionless, open access financial products and protocols.
        </div>
    )
}

export default defi;