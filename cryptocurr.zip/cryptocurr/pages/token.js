import react from 'react';

const token = () => {
    return(
        <div className="token">
            <h3 className="tok font">Top Tokenized Assets based cryptocurrencies</h3>
            Tokenized Assets are issued blockchain tokens, that represents real-world equity like: fiat currencies, shares, stock market indices or commodities.
        </div>
    )
}

export default token;