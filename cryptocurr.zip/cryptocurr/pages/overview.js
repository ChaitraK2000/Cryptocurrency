import react from 'react';
import { unstable_renderSubtreeIntoContainer } from 'react-dom';
import Details from './details';
const overview = () => {
    return(
        <div>
            <Details/>
        </div>
    )
}
export default overview;