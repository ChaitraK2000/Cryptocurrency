import React from 'react';
import Table from 'react-bootstrap/Table';
import Small from './small';
import Tab from './tab';

const navbar = ({sample}) => {
    return (
    <div className="head">
       <div className="icons">
         
          <Table size="sm" className="r">
            <thead>
                <tr>
                    <th>Market Cap</th>
                    <th>Volume(24h)</th>
                    <th>Circulating Supply</th>
                    <th>Max Supply</th>
                </tr>
            </thead>
            <tbody>
              {
                sample.map(sampl => (
                  <tr>
                  <td>{sampl.market_cap_usd}</td>
                  <td>{sampl.bitcoin_dominance_percentage}</td>
                  <td>{sampl.volume_24h_ath_value}</td>
                  <td>{sampl.market_cap_change_24h}</td>
                </tr>
                )) 
              }
            </tbody>
          </Table>
        </div>
              <Tab></Tab>
              <Small></Small>
              
    </div>)

}

export default navbar;