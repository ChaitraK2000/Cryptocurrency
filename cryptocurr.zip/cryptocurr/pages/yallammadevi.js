import React from 'react';
import Table from 'react-bootstrap/Table';
import sampleA from '../components/data/sampleA.json';
import { CircularProgressbar,  buildStyles } from 'react-circular-progressbar';

export default () => {
  const percentage= 60;
    return (
      <div>
        <Table bordered hover pagination={true} className="devi">
            <thead>
                <tr>
                    <th>Rank</th>
                    <th>Source</th>
                    <th>Price</th>
                    <th>Volume (24h)</th>
                    <th>Confidence</th>
                    <th>Liquidity(%)</th>
                    <th>Category</th>
                    <th>Updated</th>
                </tr>
            </thead>
            <tbody>
              {
                sampleA.map(samp => (
                  <tr>
                  <td>{samp.rank}</td>
                  <td>{samp.source}</td>
                  <td>{samp.price}</td>
                  <td>{samp.volume}</td>
                  <td><CircularProgressbar className="circle"
  value={percentage}
  text={`${percentage}%`}
  styles={buildStyles({
    // Rotation of path and trail, in number of turns (0-1)
    rotation: 0.25,
 
    // Whether to use rounded or flat corners on the ends - can use 'butt' or 'round'
    strokeLinecap: 'butt',
 
    // Text size
    textSize: '40px',
 
    // How long animation takes to go from one percentage to another, in seconds
    pathTransitionDuration: 0.5,
 
    pathColor: `rgba(62, 152, 199, ${percentage / 100})`,
    textColor: '#94753b',
    trailColor: '#d6d6d6',
    backgroundColor: '#2b9e8b',
  })}
/></td>
                  <td>{samp.liquidity}</td>
                  <td>{samp.category}</td>
                  <td>{samp.updated}</td>
                </tr>
                )) 
              }
            </tbody>
          </Table>
          </div>
    );
            }