import { react, Component } from "react";


class demo extends Component {

    render() {
        return(
        <div className="out">
            <div className="in">
            <iframe className="frame" src="https://widget.coinlib.io/widget?type=chart&theme=light&coin_id=859&pref_coin_id=1505" width="100%" height="536px" scrolling="auto" marginwidth="0" marginheight="0" frameborder="0" border="0"></iframe>
            </div>
            <div className="inner">
            <a href="https://coinlib.io" target="_blank" className="aa">Cryptocurrency Prices</a>&nbsp;by Coinlib</div></div>

    )

}
}
export default demo;