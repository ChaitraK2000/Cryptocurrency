import react from 'react';

const navig = () => {
    return(
        <div className="navb">
            <a className="navig active">Invest in Coinpaprika & Coins</a>
            <a className="navig"> Market Overview</a>
            <a className="navig">Currencies</a>
            <a className="navig">Exchanges</a>
            <a className="navig">Transparency</a>
            <a className="navig">Buy/Sell Crypto</a>
            <div className="sid"><span className="me">BTC Dominance:60.11%</span><br/>
                Market Cap:$402 228 418 932(0.39%)
                Vol 24h:$52 275 904 372</div>
        </div>
    )
}

export default navig;