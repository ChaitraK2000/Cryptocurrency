import {react,useState,useEffect} from 'react';
import { ThemeProvider,createGlobalStyle } from 'styled-components';
import storage from 'local-storage-fallback';
import data from '../components/data/coins.json';
import sample from '../components/data/sample.json';
import Navbar from './navbar';
import Para from './para';
import Yallammaa from './yallammaa';
import Yallammadevi from './yallammadevi';
import Vedio from './vedio';
import Rank from './rank';
import Pop from './pop';



const GlobalStyle = createGlobalStyle`
body {
    background-color: ${props => props.theme.mode === 'dark' ? '#141d26' : '#EEE'};
    color: ${props => props.theme.mode === 'dark' ? '#EEE' : '#111'};   
}`;

function getInitialTheme() {
    const savedTheme = storage.getItem('theme')
    return savedTheme ? JSON.parse(savedTheme) : { mode: 'light' }
}

function second() {
    const [theme,setTheme] = useState(getInitialTheme);
    useEffect(()=>{
        storage.setItem('theme', JSON.stringify(theme))
    },[theme]);

    
        const dataa = data.map((val => {
            return val.name;
        }))
        console.log(dataa);
        
        return (
            <ThemeProvider theme={theme}>
            <>
            <GlobalStyle/>
                <div>
                    <button className="toggle" onClick={e=>setTheme(theme.mode === 'dark' ? {mode:'light'} : {mode:'dark'})}><img width="20px" src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAOEAAADhCAMAAAAJbSJIAAAAhFBMVEX///8AAAD39/f8/Pz5+fnx8fFBQUHk5OTe3t42Njbo6OjY2Nju7u7V1dXDw8NhYWF4eHiRkZG8vLyLi4vJyckJCQmvr6+dnZ2FhYVYWFhJSUmmpqYYGBghISEvLy9qamooKChISEiYmJhRUVETExN+fn5xcXEsLCwjIyM9PT1mZma0tLSTDRsjAAAGUElEQVR4nO2daXeqPBDHb1gEEbQgi7sVl1b9/t/vae3TVi1ISCZM4pnfq76598z/AMns/vtHEARBEARBEARBEARBEARBEARBGINtWQ62DUrxxstslGJboQ53uGKfDLENUYU/Zl8csS1Rgz2csm9sbGNUYJerH4EM2xgVOKOMPbXCgF2zwDYHHHuY3SjsYxsEjTVf3ghkM2yLgHHLxa1ANsU2CRZrsrsTyE7YNoFiv9zrY+yAbRQoo78C2Qu2UZBUCXwmhfahSuATKbQmlQKf5zu0yj+n6BdrbMuAsPPXaoFshG0aEOmqRiDbYpsGQ9CvE/gsEXC9QLbEtg2Edb3A54gP80cCnyGLEb09VBhg2ydNUOms/WJ8OtEus8cKC2wLZUkfv6Pmu21N7yhjPWwT5bDnTQJNvy4GDR/hJyG2kVI8vOv/J8E2UoYhh0A2wbZShiOPQpPziRzHzAdHF9tOYawel8JXc72amEsgYzG2oaIEW06FxqZqCo678MJmgG2qGF6jv/bNIse2VYwz7yNkbIxtqxBhdYq7kqmPba0IKf8jZJmJjpvFe1VciA3s/vKWzbp+ORp4miZtBJoYXzjTZlXXnIzzTYNmUbcY95oWbRVOTEsMPyhU1GBhm9wOp7VAVmLb3A6+0PcWbJvb0fIkvTDHNroNTlOeu4qjSV/i8L55jYfMpALGuFlPBVuD6mwnIYUGPcSQN0Fz/xCNcWyGta0lDcSmODZFTftTI++mTNCIHTSfvJgRYlT1yfJyxjaeC/404l9WRtwY0UZcoRlt34mIz/aDCfmMvEUe8S9LA95TkdDpiqn+mcXWGYxbdqXu977TKhdcQV/3iqm7l1TItpqXMYIWJZka1nq32Mhc+N/onVv0RZI092idtBnMABRqffFLOW2/aBxIRXxdNE2s9JUIpJD1tJUIpZBtImwpNYAp1LYyDHOWXljq6dz4grnESrR8UUFu/B8SDb2bgKfzmZtsrl/6LZRItVWwG2sX9NcN/IqSrbU7b0pYhRre/ZJ5mgp2mhX54RUyNtMqJj6LVICbeEs0KoKn7ZtpeNjr48MNIJ2aK2baXI0u6JV/zUGXPCPwhXjFaqLH3SibEn5EP9bhxDm/K5TIFgV+YWMAFgPXMA+xRYLGT1W8lwOAczWIIk/wn8JGF9UaJ4modV84Ub5eZNNE7G2Yi7abtCEblUPhU8fPJ5vL/yI4GugpPWp+6a/jVCAHEOb77Y9neRDzeLmmY0FYzV7aFQC84tS7ngWZiTmD6u78KnabOOJ6lEG+fr9vMhAsVvqdKrzweiqiMHQt616r7ViuG3rn/z+8e8aCF0+36n7Y9Ub74pxGUTS48PFHMo8P2wethKKzjx3cFzAIlw4ibMt5eRH1jhzRFtOO2QkXm23Jppqu2IhHYwinqQgS639c+Z6TDljIJA241ppgI7XfyFMeQgEg19SiIjEMjVwgHcHVglUhu/tHvGW/K2Trdml3MZQYe+n6snQbpmLk0iCf+Hq7bhCZV62/xD5EpcdVUWeDogTJuWp8JwKNAnJu+0IAbJwzxVZSxxSqFmlpetgs4SqRvp7vKeTvFSjpW5DlDbIIKT9gogDYPnlfvxgDep9o0mplVAfArzbQ7D3dKWiTU9NCJIqKeRyt/NOJkmaOVJ9PcSQfFVZhd1L35uGoqjdeG+9NXd8YcPe3KCp3NoQAg5fSqN2AE+L74KpXbLrYEtU3/eE+xWzcQQMu7MBQW4GdNMP7YjuyIIg7aqH2lHVIN1B01njbZkU0IPMOR+BsjFiq4xm/ztPEynzRWobdxosYs2/+SWoNUSt2McrIVBjX/aQlNH2s/WhWsulE4AFxdNHr4ExdzFGH+pyWa9vbs+XrHFaIqzQqXmixDjWdqsrfLEeaTJ26hZJhxcVIow0+fgkfNY5yXWYxv4hKWB9nmqtJiUrgDAqpZZI3bCXnoRThBHOYQaJpqskBU8VwI61vr8cMbT3BeCNc38jetkb8LpY93E8FPsldb13q/vh+cZPysGkTXL1Ox3MtVxE9wI3O8wNXc+qHunxoztO7IRikSbw+1j/Mt+0+TyNPh9l1caww8Pw0jw+jWf918SE22y1Xve16UiQD3wtc7MgBDNv5wPrm42/7aaQRBEEQBEEQBEEQBEEQBEEQBEEQF/4Dz99svED5JiAAAAAASUVORK5CYII="/></button>
                <div className="second">
                <h1 className="top"><img className="lo" src="https://encrypted-tbn0.gstatic.com/images?q=tbn%3AANd9GcTCg56DuarohoU6E2taIGPU9MtsmJmML2gHrA&usqp=CAU" width="100px"></img>{dataa[0]}</h1>
                <h4 className="h3">{data[0].symbol}</h4>
                </div>
                <Rank/>
                <Pop/>
                <Vedio/> 
                <Navbar sample={sample}/>
                <Para/>
                <Yallammaa/>                    
                </div>
          </>
          </ThemeProvider>
    )
}

export default second;