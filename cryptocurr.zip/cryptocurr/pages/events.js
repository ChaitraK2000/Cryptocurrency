import react from 'react';
import Table from 'react-bootstrap/Table';
import Small from './small';
const events = () => {
    return(
        <div className="main">
        <div className="events"><h3 class="past"><b>Bitcoin Past Events</b></h3>
         
        <Table bordered hover pagination={true} className="past1">
            <thead>
                <tr>
                    <th>Date</th>
                    <th>Event description</th>
                </tr>
            </thead>
            <tbody className="ev">
                <tr>
                    <td>25 August 2020<br/>
                        29 days ago</td>
                    <td><a>SuperTx Liquidity Pool</a></td>
                </tr>
                <tr>
                <td>25 August 2020<br/>
                    29 days ago</td>
                <td><a>BiONE Lists ETF Pairs</a></td>
                </tr>
                <tr>
                <td>07 August 2020<br/>about 1 month ago</td>
                <td><a>BTC & ETH Monthly Options</a></td>
                </tr>
                <tr>
                <td>12 May 2020<br/>4 months ago</td>
                <td><a>Block Reward Halving</a></td>
                </tr>
                <tr>
                <td>11 May 2020<br/>5 months ago</td>
                <td><a>Block Reward Halving</a></td>
                </tr>
                <tr>
                <td>09 May 2020<br/>5 months ago</td>
                <td><a>Magical Crypto Conference</a></td>
                </tr>
                <tr>
                <td>25 April 2020<br/>5 months ago</td>
                <td><a>The Bitcoin Reformation</a></td>
                </tr>
                <tr>
                <td>30 March 2020<br/>6 months ago</td>
                <td><a>CME Futures BTCH20 </a></td>
                </tr>
                <tr>
                <td>25 August 2020<br/>
                    29 days ago</td>
                <td><a>BiONE Lists ETF Pairs</a></td>
                </tr>
                <tr>
                <td>25 August 2020<br/>
                    29 days ago</td>
                <td><a>BiONE Lists ETF Pairs</a></td>
                </tr>
                <tr>
                <td>25 August 2020<br/>
                    29 days ago</td>
                <td><a>BiONE Lists ETF Pairs</a></td>
                </tr>
                <tr>
                <td>25 August 2020<br/>
                    29 days ago</td>
                <td><a>BiONE Lists ETF Pairs</a></td>
                </tr>
                <tr>
                <td>25 August 2020<br/>
                    29 days ago</td>
                <td><a>BiONE Lists ETF Pairs</a></td>
                </tr>
                
            </tbody>
            </Table>
            </div>
            <div className="event2"><h3 className="upc"><b>Bitcoin Upcoming Events</b></h3>
            <Table bordered hover pagination={true} className="upcom">
            <thead>
                <tr>
                    <th>Date</th>
                    <th>Event description</th>
                </tr>
            </thead>
            <tbody className="ev">
                <tr>
                    <td>25 August 2020<br/>
                        29 days ago</td>
                    <td><a>SuperTx Liquidity Pool</a></td>
                </tr>
                <tr>
                <td>25 August 2020<br/>
                    29 days ago</td>
                <td><a>BiONE Lists ETF Pairs</a></td>
                </tr>
                </tbody>
                </Table></div>
        </div>
    )
}

export default events;