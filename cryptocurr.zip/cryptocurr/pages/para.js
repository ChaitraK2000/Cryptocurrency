import react from 'react';

const para = () => {
    return(
        <div className="para just"><h3><b>About Bitcoin</b></h3>
        <h3 className="x"><b>Bitcoin Statistics</b></h3>
        <h4><b>What Is Bitcoin?</b></h4>
        <p className="just">Bitcoin is a completely decentralized digital cryptocurrency.
         Unlike US dollars that you can hold in your hand (or in your bank account),
        there is no central authority or centralized payment system controlling Bitcoin.
        Instead, Bitcoin operates in a peer-to-peer network that allows anyone in the
        world to send and receive Bitcoin without any middleman (like a bank, central
        bank or payment processor).
        <br></br><br></br>

        Although there are thousands of cryptocurrencies ranked on CMC today, Bitcoin was
        the very first cryptocurrency ever created. On Oct. 31, 2008 a person (or group of
        people) under the pseudonym “Satoshi Nakamoto” published the now-world famous Bitcoin
        white paper.
        <br></br><br></br>
        The first line reads: “A purely peer-to-peer version of electronic cash, which would 
        allow online payments to be sent directly from one party to another without going through
        a financial institution.”
        <br></br><br></br>
        The Bitcoin network then launched on Jan. 3, 2009, marking the start of the cryptocurrency
        revolution.
        <br></br><br></br>
        <h4><b>How Does Bitcoin Work?</b></h4>
        Bitcoin is a purely decentralized digital currency, which makes it unlike any other asset
        that came before it.
        <br></br><br></br>
        Before the digital age, everyone transacted in physical forms of currencies, from livestock
        and salt, to silver and gold, and finally to banknotes. Only in recent times was money “digitized”
        — allowing bank accounts to exist online, as well as creating the many online payment processing
        platforms, such as PayPal and Square, that you often use today without thinking about it.
        <br></br><br></br>
        However, all of these “digital transactions” require a centralized system to operate.
        Your bank, or financial services like PayPal, needs to ensure that all of their users’ accounts
        are constantly updated and tallied correctly. These systems represent the centralized form of
        digital money.
        <br></br><br></br>
        Bitcoin revolutionized digital money by decentralizing this accounting process. 
        Instead of a central figure that is responsible for making sure that their users’ transactions
        were always adding up, Bitcoin works by sharing the account balances and transactions of every
        user across the globe in a pseudonymous form. In simplest terms, this means that anyone can
        download and run the free and open-source software required to participate in the Bitcoin protocol.
        <br></br><br></br>
        As a Bitcoin user, all you need to know to send Bitcoin to someone else is their Bitcoin address
        (a series of letters and numbers, not their name or any personal information!). By sending your
        Bitcoin to an address, what you are doing is broadcasting your transaction (Hi, I’m Alice sending
        1 BTC to Bob!) across the Bitcoin network using blockchain technology (more about that below).
        Since the Bitcoin network has the most up-to-date ledger tracking Alice’s wallet balance, the
        system checks her wallet balance (i.e., Alice has 2 BTC in her wallet, so a transaction of 1 BTC
        to Bob is valid), and then completes the transaction.
        <br></br><br></br>
        In summary, Bitcoin works by ensuring that this shared ledger always tallies up, and that new
        Bitcoin transactions (Bob sends 2 BTC back to Alice. Go Alice!) are validated, recorded and
        then added to the ledger in order. That is the heart of blockchain technology, where new “blocks
        of information” are added to the chain of blocks that already exist.
            <br></br><br></br>
        <h4><b>How Does Bitcoin Mining Work?</b></h4>
        “Mining” refers to the act of adding new blocks to the blockchain. In simple terms, Bitcoin
        miners dedicate significant amounts of computing power to solve a cryptographic problem, which
        is basically a very complex puzzle. The successful miner that solves the puzzle before all the
        other miners gets rewarded with a “block reward,” which is an allocation of a predetermined number
        of Bitcoin. In some cases, the block rewards are awarded to mining pools, when miners group together
        to share resources.
        <br></br><br></br>
        Once the puzzle is solved, the block is “confirmed,” and it is added to the blockchain.
        This new information is sent to all nodes, aka participants in the Bitcoin protocol, and the shared
        ledger is updated once again.
        <br></br><br></br>
        As Bitcoin's price rises, the block reward becomes increasingly more attractive. This incentivizes
        more miners to join in the competition to mine for blocks. In return, the more miners there are in
        the system, the more secure the network is. In addition, the increased competition also means miners
        are continually investing in newer hardware to ensure their computing power remains relevant for the
        fight for block rewards.
        <br></br><br></br>
        <h4><b>What Is a Bitcoin Halving?</b></h4>
        To ensure that the value of Bitcoin is not compromised by an infinite supply, Satoshi Nakamoto wrote
        in a “halving event” that happens every 210,000 blocks. When Bitcoin’s network first began, Bitcoin’s
        block reward was 50 BTC per block mined. This was halved in 2012, at block #210,000, where the block
        reward became 25 BTC. The second halving was in 2016, at block #420,000, and the block reward became
        12.5 BTC.
        <br></br><br></br>
        This process will continue every 210,000 blocks, until the total supply of BTC (21 million BTC) has
        been reached. It is estimated that the final block reward will be paid in 2140! For more information
        on the Bitcoin halving, check out our Bitcoin Halving page and blog post!
        <br></br><br></br>
        <h4><b>How Can I Store my Bitcoin?</b></h4>
        There are many different ways of storing your Bitcoin – here’s just a few:
        <br></br><br></br>
        Keep it on a Bitcoin exchange
        There are many Bitcoin different exchanges all over the world. All of these exchanges allow you to
        sell Bitcoin for other cryptocurrencies (altcoins) or government currencies (USD, EUR, GBP etc.)
        At the same time, these Bitcoin exchanges allow you to store your BTC with them, which means that 
        the burden of keeping it safe is on them. Do note that incidents have occurred when exchanges have 
        been hacked or lost their customers’ BTC, so do your own research when you’re looking for an exchange 
        that’s safe to hold your cryptoassets. For the latest list of exchanges and trading pairs for this 
        cryptocurrency, click on our market pairs tab.
        <br></br><br></br>
        Keep it in a Bitcoin wallet
        Instead of keeping it on a Bitcoin exchange, you could keep your Bitcoin in a Bitcoin wallet instead. 
        Wallets come in two forms — hot and cold. Hot wallets are software that stays connected to the internet, 
        aka storing your Bitcoin online. It is more convenient to transact via a hot wallet, but they logically 
        are more susceptible to being attacked, as they stay connected to the internet.
        <br></br><br></br>
        Cold wallets are wallets that are not “online.” They are less prone to attack, as hackers cannot access 
        this type of cold storage via the internet, but they are also a lot less convenient for the user as they 
        may be cost-prohibitive and require more technical understanding to operate. Examples of cold wallets are 
        hardware wallets and paper wallets.<br></br>

</p></div>
    )
}

export default para;