import React, { useState,useEffect } from 'react';
import DatePicker from 'react-datepicker';
import {BootstrapTable, TableHeaderColumn} from 'react-bootstrap-table';
import data from "../components/data/data.json";

const Table = () => {     
  const [startDate, setStartDate] = useState(new Date("2020-09-17"));
  const [endDate, setEndDate] = useState(new Date());
    
      let result = data.filter((function(obj){
             return new Date(obj.date) >= startDate && new Date(obj.date) <= endDate;
      }));
    
    return (
      <div class="his">
        <div className="datepicker">
        <DatePicker selected={startDate} onChange={startDate => setStartDate(startDate)} className="date1 date" />
        <DatePicker selected={endDate} onChange={endDate => setEndDate(endDate)} className="date1"/>
        </div>
        <div>
        <BootstrapTable data={result} className="sim" trClassName='tr-style' rowClasses="custom-row-class"  hover={true} condensed= {true} sort={ { dataField: 'date', order: 'asc' } } pagination={true}> 
          <TableHeaderColumn isKey dataField='date' className="sty" dataSort columnTitle>
                Date
          </TableHeaderColumn>
          <TableHeaderColumn dataField='market-cap' className="sty" dataAlign="center" >
                Market-Cap
          </TableHeaderColumn>
          <TableHeaderColumn dataField='volume' className="sty" dataAlign="center">
                Volume
          </TableHeaderColumn>
          <TableHeaderColumn dataField='open' className="sty" dataAlign="center" dataSort columnTitle tdStyle={{ whiteSpace: 'normal', wordWrap: 'break-word' }}>
                Open
          </TableHeaderColumn>
          <TableHeaderColumn dataField='close' className="sty" dataAlign="center" dataSort columnTitle>
               Close
          </TableHeaderColumn>
    </BootstrapTable>
    </div>
      </div>
    );
  }
 
export default Table;
