import react, { Component } from 'react';
import Table from 'react-bootstrap/Table';


class Small extends Component{

    render() {
        return(
            <div className="sm">
               <Table hover className="small">
                  <thead className="thead">
                    <tr>
                      <th>Related Cryptocurrencies</th>
                    </tr>
                  </thead>
                  <tbody>
                    <tr>
                      <td><a>Tether(USDT)</a></td>
                    </tr>
                    <tr>
                      <td><a>Ethereum(ETH)</a></td>
                    
                    </tr>
                    <tr>
                      <td><a>Polkadot(DOT)</a></td>
                      
                    </tr>
                    <tr>
                      <td><a>Binance coin(BNB)</a></td>
                      
                    </tr>
                    <tr>
                      <td> <a>Bitcoin Cash (BCH)</a></td>
                      
                    </tr>
                  </tbody>
                </Table>
            </div>
        )
    }
}

export default Small;