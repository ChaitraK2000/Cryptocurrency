import react from 'react';
import Table from 'react-bootstrap/Table';

const yallammaa = () => {
    return(
        <div>
                <Table bordered hover size="sm" className="v">
                
                <tr>
                    <th>Bitcoin Price</th>
                    <td>$10,312.41 USD</td>
                </tr>
                <tr>
                    <th>Bitcoin ROI</th>
                    <td>7,521.89%</td>
                </tr>
                <tr>
                    <th>Market Rank</th>
                    <td>#1</td>
                </tr>
                <tr>
                    <th>Market Cap</th>
                    <td>$190,625,139,207 USD</td>
                </tr>
                <tr>
                    <th>24 Hour Volume</th>
                    <td>$53,795,361,656 USD</td>
                </tr>
                    <tr>
                    <th>Circulating Supply</th>
                    <td>18,485,018 BTC</td>
                    </tr>
                    <tr>
                    <th>Total Supply</th>
                    <td>18,485,018 BTC</td>
                </tr>
                <tr>
                    <th>Max Supply</th>
                    <td>21,000,000 BTC</td>
                </tr>
                <tr>
                    <th>All Time High</th>
                    <td>$20,089.00 USD
                        (Dec 17, 2017)</td>
                </tr>
                <tr>
                    <th>All Time Low</th>
                    <td>$65.53 USD(Jul 05, 2013)</td>
                </tr>
                <tr>
                    <th>52 Week High / Low</th>
                    <td>$12,359.06 USD /$4,106.98 USD</td>
                </tr>
                <tr>
                    <th>90 Day High / Low</th>
                    <td>$12,359.06 USD /$8,975.53 USD</td>
                </tr>
                <tr>
                    <th>30 Day High / Low</th>
                    <td>$12,359.06 USD /$11,094.15 USD</td>
                </tr>
                <tr>
                    <th>7 Day High / Low</th>
                    <td>$12,067.08 USD /$11,185.94 USD</td>
                </tr>
                <tr>
                    <th>24 Hour High / Low</th>
                    <td>$12,067.08 USD /$11,352.59 USD</td>
                </tr>
                <tr>
                    <th>Yesterday's High / Low</th>
                    <td>$10,350.54 USD /$10,017.25 USD</td>
                </tr>
                <tr>
                    <th>Yesterday's Open / Close</th>
                    <td>$10,134.15 USD /$10,242.35 USD</td>
                </tr>
                <tr>
                    <th>Yesterday's Change</th>
                    <td>$108.20 USD (1.07%)</td>
                </tr>
                <tr>
                    <th>Yesterday's Volume</th>
                    <td>24,128,292,755 USD</td>
                </tr>

                
            </Table>
      </div>
    )
}

export default yallammaa;