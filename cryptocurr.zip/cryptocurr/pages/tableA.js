import react from 'react';
import data from '../components/data/coins.json';
import React, { Component } from 'react';
import Table from 'react-bootstrap/Table';
class TableA extends Component {
render() {
     
    return (
     
      <div>
        <Table variant="dark" hover className="new">
            <thead>
                <tr>
                    <th className="q x">#</th>
                    <th className="q">Name</th>
                    <th className="q">Symbol</th>
                    <th className="q">Price</th>
                    <th className="q">1h</th>
                    <th className="q">24h</th>
                    <th className="q">Volume(24h)</th>
                    <th className="q">%/hr</th>
                    <th className="q">%/day</th>
                    <th className="q">%/week</th>
                    <th className="q">Market Cap</th>    
                </tr>
            </thead>
            <tbody>
              {
                data.map(samp => (
                  <tr>
                  <td width="55px">{samp.rank}</td>
                  <td><a href="second">{samp.name}</a></td>
                  <td>{samp.symbol}</td>
                  <td>{samp.volume_24h_ath_value}</td> 
                  <td>{samp.oh}</td>
                  <td>{samp.th}</td>
                  <td>{samp.volume_24h_change_24h}</td>
                  <td>{samp.bitcoin_dominance_percentage}</td>
                  <td>{samp.market_cap_change_24h}</td> 
                  <td>{samp.bitcoin_dominance_percentage}</td> 
                  <td>{samp.market_cap_ath_value}</td>   
                  </tr>
                ))}
            </tbody>
        </Table>
      </div>
    );
  }
}
 
export default TableA;
