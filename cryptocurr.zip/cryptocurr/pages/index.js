import {react,} from 'react';
import data from '../components/data/coins.json';
import Table from './tableA';
import Navig from './navigation';
import Nav from './nav';
const page = () => {
    const mystyle = {
        padding: "10px",
        marginTop: "100px",
        marginLeft: "30px",
        color: "Black",
        fontSize: "26px",
        fontFamily: "Lucida Console"
    }
    
    return (
            <div className="w">
            <Navig/>
            <hr/>
            <Nav/>
            <Table data={data}/>
            </div>  

    )
}
export default page;