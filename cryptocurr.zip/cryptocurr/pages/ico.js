import react from 'react';

const currencies = () => {
    return(
        <div>
            <h3 className="icoj font">Initial Coin Offerings (ICO's) on Cryptocurrency Market.</h3>
               <p className="ico"> Initial Coin Offering (ICO) is a type of funding using cryptocurrencies. Learn about active, upcoming or already ended ICO's on Coinpaprika.</p>
        </div>
    )
}

export default currencies;