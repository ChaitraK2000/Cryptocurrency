import React, { useState } from 'react';
import DatePicker from 'react-datepicker';
 
function MyApp() {
  const [value, onChange] = useState(new Date());
  const [val,onSet]= useState(new Date());
  console.log(value,val);
 
  return (
    <div>
      <DatePicker
        onChange={onChange}
        value={value}
      />
      <br/>
      <br/>
      <DatePicker
        onChange={onSet}
        value={val}
      />
    </div>
  );

}


export default MyApp;