import react, { Component } from 'react';
import Table from 'react-bootstrap/Table';


class Social extends Component{

    render() {
        return(
            <div className="social"> 
                <h4 className="s"><b>links from <a>Bitcoin.reddit.com</a></b></h4>
                <div >
                    <a>Bitcoin Newcomers FAQ - Please read!</a><br/>
                    297 points | 158 comments<br/>
                    </div>
                    <div>
                    <a>Daily Discussion, September 15, 2020</a><br/>
                    5 points | 20 comments<br/>
                    </div>
                    <div>
                     <a>When you over trade bitcoin</a><br/>
                     
                    1926 points | 60 comments<br/>
                    </div>
                    <div>
                    <a>Security first</a><br/>
                    1868 points | 101 comments<br/></div>
                    <div>
                    <a>Pomp Podcast #383: Jim Cramer Becomes A Bitcoin Bull</a><br/>
                    121 points | 16 comments<br/></div>
                    <div><a>Weekly Bitcoin Core PR Review Club: PR #19845 (part of a proposed implementation of the BIP155 "addrv2" message)</a><br/>
                    • points | 1 comment<br/></div>
<div><a> Seen at a convenience store. Sanandaj / Iran.</a><br/>
                    • points | comment<br/>
                    </div>
                    <div><a>Why Anthony Pompliano Thinks Bitcoin Will Hit $100K By 2022 (1.5-minute audio clip from his podcast with Jim Cramer)</a><br/>
                    • points | comment<br/></div>
                    <div><a>Some Bitcoin Traders Are Betting on a $36K Price by Year’s End</a><br/>
                    48 points | 24 comments<br/></div>
                    <div><a>MicroStrategy Tells SEC It 'May Increase' $250M Bitcoin Reserves</a><br/>
                    • points | 1 comment<br/></div>
                    <div><a>Bitcoin Satellite - We have installed the Blockstream Bitcoin Satellite system, a way to download and verify Bitcoin’s blockchain via satellite, without the need for an internet connection</a><br/>
                    176 points | 8 comments<br/></div>
            </div>
        )
    }
}

export default Social;